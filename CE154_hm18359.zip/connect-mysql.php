<!-- 1805243 -->

<?php
$servername = "localhost";
$username = "hm18359";
$password = "XCQtg6WaF2G1a";
$dbname = "ce154_hm18359";
$errors = "";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

if (isset($_POST['submit'])) {
    $task = mysqli_real_escape_string($conn, $_POST['task']);
    if (empty($task)) {
        $errors = "You must fill in the task";
    }else {     
            $query = "INSERT INTO users (Details) VALUES ('$task')";
			mysqli_query($conn, $query);
			
			echo $query;
            header('location: index.php');
    }
    
}

$tasks = mysqli_query($conn, "SELECT * FROM users ORDER BY (Due) ASC");

//edit saved tasks
/*if (isset($_POST['modify'])) {
    $edit = mysqli_real_escape_string($conn, $_GET['modify']);
    $id = intval($_GET['id']);
    $res = mysqli_query($conn, "SELECT * FROM users WHERE id='$edit'");
    $row = mysqli_fetch_array($res);
    $newTask = $_POST['editTask'];
    $sql = mysqli_query($conn, "UPDATE users SET Details='$newTask' WHERE id='$edit'"); 
    header('location: index.php');
}*/

/* $newText = $_POST['edit'];

if ($newText != "") {
    $id = intval($_GET['id']);
    $sql = "UPDATE users SET Details = '".$newText."' WHERE id=$id ";
    $result = mysqli_query($conn, $sql);
}*/


// delete task
if (isset($_GET['del_task'])) {
    $remove = mysqli_real_escape_string($conn, $_GET['del_task']);
    mysqli_query($conn, "DELETE FROM users WHERE id=$remove");
    header('location: index.php');
}

// update due date 
if(isset($_POST['change_date'], $_POST['due'], $_POST['task_id']))
{
	$newStamp = intval($_POST['due']);
	$taskId = intval($_POST['task_id']);
	
	mysqli_query($conn, "UPDATE users SET Due = '" . $newStamp . "' WHERE ID = '" . $taskId . "'");
}



function myDate($dy) {
  $daynum = date('w', $dy);
  return '<option value="' . $dy . '">' . date("l jS F", $dy) . '</option>';
}

/*echo '<select name="day">';

$d = strtotime("today");
while ($d < strtotime("+7 days")) {
  echo myDate($d);
  $d += 86400; // number of seconds in a day, to get to next day
  }

echo '</select>';*/


/* echo "Connected successfully"; */
?>