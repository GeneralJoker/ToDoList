<!-- 1805243 -->

<?php

require_once 'init.php';

?> 

<!DOCTYPE html>
<html>

	<head>

		<meta charset = "UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<link rel="stylesheet" type="text/css" href="css/style.css?v=1.1"/>
        <link href="https://fonts.googleapis.com/css?family=Alef" rel="stylesheet">
		<link href='https://fonts.googleapis.com/css?family=Sofia' rel='stylesheet'>
        <?php include 'connect-mysql.php' ;?>
		<title>CE154 1805243 Assignment</title>
        
	</head>

	<body>
	
		
		<!-- Header -->
		<article id="header">
			
			<header>
				<h1>CE154 Task Manager</h1>
			</header>
		
		</article> 
		
		
		<!-- Navigation bar -->
		<!--<article id="nav">
			<nav>
				<div>
					<a class="main" href="#Project1">Project 1</a>
				</div>
			</nav>
			
		</article>-->
		
		
		<!-- Page content -->
		<article id="content">
			<section>
                
                <form action="connect-mysql.php" method="POST">
                <?php if (isset($errors)) { ?> 
                    <p><?php echo $errors; ?></p>
                <?php } ?>
                    
                    <input type="text" name="task" class="task_input">
                    <button type="submit" class="add" name="submit">Add Task</button>    
                </form>
                
                <table>
                    <thead>
                        <tr>
                            <th>N</th>
                            <th>Task</th>
                            <th colspan="2">Action</th>
                            <th>Due</th>
							<th>Update</th>
                        </tr>
                    </thead>
                    
                    <tbody>
                    <?php $i = 1; while ($row = mysqli_fetch_array($tasks)) { ?>    
                        <tr>
                            <td><?php echo $i; ?></td>
                            <form method="post" action="<?php echo $_SERVER['PHP_SELF'];?>">
                                <td class="task" contenteditable="true" onblur="saveText()"><?php echo $row['Details']; ?><input type="hidden" name="editTask"></td>   
                                <td class="edit"><input type="image" name="modify" src="images/refresh-512.png" height="25px" width="25px"></td> 
                            </form>    
                            <td class="delete"><a href="index.php?del_task=<?php echo $row['ID']; ?>">x</a></td>
							<td class="deadline">
								<?php echo date('l jS F', $row['Due']); ?>
							</td>
                            <td class="deadline">
							<form method='post'>
                            <select name="due">    
                            <?php
                                $d = strtotime("today");
                                while ($d < strtotime("+7 days")) {
                                    echo myDate($d);
                                    $d += 86400; // number of seconds in a day, to get to next day
                                }                                                
                            ?>
							
							
                            </select>
							<input type='hidden' name='task_id' value='<?php echo $row['ID']; ?>'>
                                <button type="submit" name="change_date" class="add">Choose Date</button> 
							</form>
                            </td>
                        </tr>
                    <?php $i++; } ?>
                        
                    </tbody>
                    
                </table>
                
			</section>
			
		</article>
		
		
		<!-- Footer -->
		<article id="footer">
		
			<footer>
				<p>Hamza Mohamed 2019 ©</p>
				<p id="contact">Contact information: <a href="mailto:hm18359@essex.ac.uk">
				hm18359@essex.ac.uk</a></p>
			</footer>
			
		</article>
			
			
	</body>

</html>